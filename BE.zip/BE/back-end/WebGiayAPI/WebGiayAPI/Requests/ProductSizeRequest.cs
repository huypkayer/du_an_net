﻿namespace WebGiayAPI.Requests
{
    public class CreateProductSizeRequest
    {
        public int ProductId { get; set; }
        public int Size { get; set; }
        public int StockQuantity { get; set; }
    }
    public class UpdateProductSizeRequest
    {
        public int ProductId { get; set; }
        public int Size { get; set; }
        public int StockQuantity { get; set; }
    }

}
