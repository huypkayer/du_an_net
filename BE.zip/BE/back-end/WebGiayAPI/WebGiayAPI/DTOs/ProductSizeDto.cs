﻿namespace WebGiayAPI.DTOs
{
    public class ProductSizeDto
    {
        public int ProductSizeId { get; set; }
        public int ProductId { get; set; }
        public int Size { get; set; }
        public int StockQuantity { get; set; }

        // Các thuộc tính điều hướng
        public ProductDto Product { get; set; }
    }
}
