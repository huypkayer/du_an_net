﻿namespace WebGiayAPI.DTOs
{
    public class ProductImageDto
    {
        public int ImageId { get; set; }
        public int ProductId { get; set; }
        public string ImageUrl { get; set; }
        public DateTime CreatedAt { get; set; }

        // Các thuộc tính điều hướng
        public ProductDto Product { get; set; }
    }
}
