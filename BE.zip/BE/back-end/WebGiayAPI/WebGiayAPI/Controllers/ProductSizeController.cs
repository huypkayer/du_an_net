﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebGiayAPI.DTOs;
using WebGiayAPI.Requests;
using WebGiayAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace WebGiayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductSizesController : ControllerBase
    {
        private readonly WebGiayAPIContext _context;

        public ProductSizesController(WebGiayAPIContext context)
        {
            _context = context;
        }

        // GET: api/productsizes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductSizeDto>>> GetProductSizes()
        {
            var productSizes = await _context.ProductSizes
                .Select(ps => new ProductSizeDto
                {
                    ProductSizeId = ps.ProductSizeId,
                    ProductId = ps.ProductId,
                    Size = ps.Size,
                    StockQuantity = ps.StockQuantity
                })
                .ToListAsync();

            return Ok(productSizes);
        }

        // GET: api/productsizes/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductSizeDto>> GetProductSize(int id)
        {
            var productSize = await _context.ProductSizes
                .Where(ps => ps.ProductSizeId == id)
                .Select(ps => new ProductSizeDto
                {
                    ProductSizeId = ps.ProductSizeId,
                    ProductId = ps.ProductId,
                    Size = ps.Size,
                    StockQuantity = ps.StockQuantity
                })
                .FirstOrDefaultAsync();

            if (productSize == null)
            {
                return NotFound();
            }

            return Ok(productSize);
        }

        // GET: api/products/{productId}/sizes
        [HttpGet("products/{productId}/sizes")]
        public async Task<ActionResult<IEnumerable<ProductSizeDto>>> GetProductSizesByProduct(int productId)
        {
            var productSizes = await _context.ProductSizes
                .Where(ps => ps.ProductId == productId)
                .Select(ps => new ProductSizeDto
                {
                    ProductSizeId = ps.ProductSizeId,
                    ProductId = ps.ProductId,
                    Size = ps.Size,
                    StockQuantity = ps.StockQuantity
                })
                .ToListAsync();

            if (!productSizes.Any())
            {
                return NotFound();
            }

            return Ok(productSizes);
        }

        // POST: api/productsizes
        [HttpPost]
        public async Task<ActionResult<ProductSizeDto>> CreateProductSize(CreateProductSizeRequest request)
        {
            var productSize = new ProductSize
            {
                ProductId = request.ProductId,
                Size = request.Size,
                StockQuantity = request.StockQuantity
            };

            _context.ProductSizes.Add(productSize);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProductSize), new { id = productSize.ProductSizeId }, new ProductSizeDto
            {
                ProductSizeId = productSize.ProductSizeId,
                ProductId = productSize.ProductId,
                Size = productSize.Size,
                StockQuantity = productSize.StockQuantity
            });
        }

        // PUT: api/productsizes/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProductSize(int id, UpdateProductSizeRequest request)
        {
            var productSize = await _context.ProductSizes.FindAsync(id);

            if (productSize == null)
            {
                return NotFound();
            }

            productSize.ProductId = request.ProductId;
            productSize.Size = request.Size;
            productSize.StockQuantity = request.StockQuantity;

            _context.Entry(productSize).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/productsizes/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductSize(int id)
        {
            var productSize = await _context.ProductSizes.FindAsync(id);

            if (productSize == null)
            {
                return NotFound();
            }

            _context.ProductSizes.Remove(productSize);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
