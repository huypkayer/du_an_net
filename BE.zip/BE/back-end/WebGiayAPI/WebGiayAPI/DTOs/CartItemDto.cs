﻿using WebGiayAPI.Models;

namespace WebGiayAPI.DTOs
{
    public class CartItemDto
    {
        public int CartItemId { get; set; }
        public int ProductId { get; set; }
        public int CartId { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public int Size { get; set; }
        public DateTime? PurchaseDate { get; set; }

        // Các thuộc tính điều hướng
        public ProductDto Product { get; set; }
        public CartDto Cart { get; set; }
    }


}
