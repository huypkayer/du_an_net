﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebGiayAPI.DTOs;
using WebGiayAPI.Models;
using WebGiayAPI.Requests;

[Route("api/[controller]")]
[ApiController]
public class UsersController : ControllerBase
{
    private readonly WebGiayAPIContext _context;

    public UsersController(WebGiayAPIContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserDto>>> GetUsers()
    {
        var users = await _context.Users
            .Select(u => new UserDto
            {
                UserId = u.UserId,
                Username = u.Username,
                Email = u.Email,
                PhoneNumber = u.PhoneNumber,
                Role = u.Role,
                CreatedAt = u.CreatedAt,
                UpdatedAt = u.UpdatedAt,
                Address = u.Address,
                Salary = u.Salary,
                IsActive = u.IsActive,
                AvatarUrl = u.AvatarUrl,
                LastLogin = u.LastLogin,
                Gender = u.Gender,
            })
            .ToListAsync();

        return Ok(users);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<UserDto>> GetUser(int id)
    {
        var user = await _context.Users
            .Where(u => u.UserId == id)
            .Select(u => new UserDto
            {
                UserId = u.UserId,
                Username = u.Username,
                Email = u.Email,
                PhoneNumber = u.PhoneNumber,
                Role = u.Role,
                CreatedAt = u.CreatedAt,
                UpdatedAt = u.UpdatedAt,
                Address = u.Address,
                Salary = u.Salary,
                IsActive = u.IsActive,
                AvatarUrl = u.AvatarUrl,
                LastLogin = u.LastLogin,
                Gender = u.Gender,
            })
            .FirstOrDefaultAsync();

        if (user == null)
        {
            return NotFound("Người dùng không tồn tại.");
        }

        return Ok(user);
    }

    [HttpPost("login")]
    public async Task<ActionResult<UserDto>> Login([FromBody] LoginRequest request)
    {
        try
        {
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == request.Email && u.Password == request.Password);

            if (existingUser == null)
            {
                return Unauthorized("Email hoặc mật khẩu không chính xác.");
            }

            existingUser.LastLogin = DateTime.UtcNow;
            _context.Users.Update(existingUser);
            await _context.SaveChangesAsync();

            var userDto = new UserDto
            {
                UserId = existingUser.UserId,
                Username = existingUser.Username,
                Email = existingUser.Email,
                PhoneNumber = existingUser.PhoneNumber,
                Role = existingUser.Role,
                CreatedAt = existingUser.CreatedAt,
                UpdatedAt = existingUser.UpdatedAt,
                Address = existingUser.Address,
                Salary = existingUser.Salary,
                IsActive = existingUser.IsActive,
                AvatarUrl = existingUser.AvatarUrl,
                LastLogin = existingUser.LastLogin,
                Gender = existingUser.Gender,
            };

            return Ok(userDto);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Đã xảy ra lỗi khi đăng nhập: {ex.Message}");
        }
    }

    [HttpPost("register")]
    public async Task<ActionResult<UserDto>> Register([FromBody] CreateUserRequestRegister request)
    {
        if (request.Password.Length < 6)
        {
            return BadRequest("Mật khẩu phải có ít nhất 6 ký tự.");
        }

        try
        {
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == request.Email || u.Username == request.Username);
            if (existingUser != null)
            {
                return Conflict(existingUser.Email == request.Email
                    ? "Email đã được sử dụng bởi người dùng khác."
                    : "Tên đăng nhập đã được sử dụng bởi người dùng khác.");
            }

            var maxUserId = await _context.Users
                .OrderByDescending(u => u.UserId)
                .Select(u => u.UserId)
                .FirstOrDefaultAsync();
            var newUserId = maxUserId + 1;

            var user = new User
            {
                UserId = newUserId,
                Username = request.Username,
                Password = request.Password,
                Email = request.Email,
                Role = "User",
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var userDto = new UserDto
            {
                UserId = user.UserId,
                Username = user.Username,
                Email = user.Email,
                CreatedAt = user.CreatedAt
            };

            return CreatedAtAction(nameof(GetUser), new { id = user.UserId }, userDto);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Đã xảy ra lỗi khi đăng ký người dùng: {ex.Message}");
        }
    }

    [HttpPost]
    public async Task<IActionResult> CreateUser([FromBody] CreateUserRequestNV request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var existingUser = await _context.Users
                .AnyAsync(u => u.Email == request.Email || u.Username == request.Username);

            if (existingUser)
            {
                return Conflict("Email hoặc tên đăng nhập đã được sử dụng.");
            }

            var maxUserId = await _context.Users
                .MaxAsync(u => (int?)u.UserId) ?? 0;

            var newUserId = maxUserId + 1;

            // Đặt mật khẩu mặc định nếu không có mật khẩu được cung cấp
            var defaultPassword = "123456";

            var user = new User
            {
                UserId = newUserId,
                Username = request.Username,
                // Bạn có thể sử dụng hàm hash mật khẩu ở đây để bảo mật hơn
                Password = defaultPassword,
                Email = request.Email,
                PhoneNumber = request.PhoneNumber,
                Gender = request.Gender,
                Salary = request.Salary,
                Role = request.Role,
                IsActive = request.IsActive,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUser), new { id = user.UserId }, user);
        }
        catch (DbUpdateException dbEx)
        {
            // Xử lý lỗi liên quan đến cơ sở dữ liệu
            var innerException = dbEx.InnerException?.Message ?? dbEx.Message;
            return StatusCode(500, $"Lỗi khi lưu dữ liệu vào cơ sở dữ liệu: {innerException}");
        }
        catch (InvalidOperationException invOpEx)
        {
            // Xử lý lỗi khi mô hình hoặc cấu hình không hợp lệ
            return StatusCode(500, $"Lỗi hoạt động không hợp lệ: {invOpEx.Message}");
        }
        catch (Exception ex)
        {
            // Xử lý các lỗi khác
            return StatusCode(500, $"Đã xảy ra lỗi khi tạo người dùng: {ex.Message}");
        }
    }



    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateUser(int id, [FromBody] UpdateUserRequest request)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound("Người dùng không tồn tại.");
        }

        user.Username = request.Username ?? user.Username;
        user.Email = request.Email ?? user.Email;
        user.PhoneNumber = request.PhoneNumber ?? user.PhoneNumber;
        user.Role = request.Role ?? user.Role;
        user.Address = request.Address ?? user.Address;
        user.Gender = request.Gender ?? user.Gender;
        user.UpdatedAt = DateTime.UtcNow;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!UserExists(id))
            {
                return NotFound("Người dùng không tồn tại.");
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    [HttpPut("UpdateUserNV/{id}")]
    public async Task<IActionResult> UpdateUserNV(int id, [FromBody] UpdateUserRequestNV request)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound("Người dùng không tồn tại.");
        }

        user.Username = request.Username ?? user.Username;
        user.Email = request.Email ?? user.Email;
        user.PhoneNumber = request.PhoneNumber ?? user.PhoneNumber;
        user.Role = request.Role ?? user.Role;
        user.Gender = request.Gender ?? user.Gender;
        user.IsActive = request.IsActive ?? user.IsActive;  // Assuming you have an IsActive field in your User model
        user.Salary = request.Salary ?? user.Salary;  // Assuming you have a Salary field in your User model
        user.UpdatedAt = DateTime.UtcNow;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!UserExists(id))
            {
                return NotFound("Người dùng không tồn tại.");
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }


    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteUser(int id)
    {
        var user = await _context.Users
            .Include(u => u.Carts) // Giả sử có quan hệ giữa Users và Carts
            .ThenInclude(c => c.CartItems) // Bao gồm CartItems trong mỗi Cart
            .FirstOrDefaultAsync(u => u.UserId == id);

        if (user == null)
        {
            return NotFound("Người dùng không tồn tại.");
        }

        try
        {
            // Xóa các mục trong giỏ hàng
            foreach (var cart in user.Carts)
            {
                if (cart.CartItems != null && cart.CartItems.Any())
                {
                    _context.CartItems.RemoveRange(cart.CartItems);
                }
            }

            // Xóa các giỏ hàng liên quan
            _context.Carts.RemoveRange(user.Carts);

            // Xóa người dùng
            _context.Users.Remove(user);

            // Lưu các thay đổi
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateException ex)
        {
            // Ghi nhận lỗi chi tiết
            return StatusCode(500, $"Đã xảy ra lỗi khi xóa người dùng: {ex.InnerException?.Message ?? ex.Message}");
        }

        return NoContent();
    }




    private bool UserExists(int id)
    {
        return _context.Users.Any(e => e.UserId == id);
    }
}
