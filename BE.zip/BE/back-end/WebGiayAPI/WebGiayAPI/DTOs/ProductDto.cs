﻿namespace WebGiayAPI.DTOs
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public int? CategoryId { get; set; }
        public string Brand { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public bool IsFeatured { get; set; }
        public decimal? Discount { get; set; }
        public string ProductImgUrl { get; set; }
        public int StockQuantity { get; set; }

        // Các thuộc tính điều hướng
        public CategoryDto Category { get; set; }
        public List<ProductSizeDto> ProductSizes { get; set; } = new List<ProductSizeDto>();
        public List<ProductImageDto> ProductImages { get; set; } = new List<ProductImageDto>();
    }
}
