﻿namespace WebGiayAPI.Requests
{
    public class CreateProductImageRequest
    {
        public int ProductId { get; set; }
        public string ImageUrl { get; set; }
    }
    public class UpdateProductImageRequest
    {
        public int ProductId { get; set; }
        public string ImageUrl { get; set; }
    }

}
