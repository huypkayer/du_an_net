﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebGiayAPI.DTOs;
using WebGiayAPI.Models;
using WebGiayAPI.Requests;

[Route("api/[controller]")]
[ApiController]
public class CartItemsController : ControllerBase
{
    private readonly WebGiayAPIContext _context;

    public CartItemsController(WebGiayAPIContext context)
    {
        _context = context;
    }

    [HttpGet("ByCartId/{cartId}")]
    public async Task<IActionResult> GetCartItemsByCartId(int cartId)
    {
        if (cartId <= 0) return BadRequest("ID giỏ hàng không hợp lệ.");

        try
        {
            var cartItems = await _context.CartItems
                .Where(ci => ci.CartId == cartId)
                .Include(ci => ci.Product)
                .ThenInclude(p => p.ProductImages)
                .Include(ci => ci.Cart)
                .ToListAsync();

            if (!cartItems.Any()) return NotFound("Không tìm thấy các mục trong giỏ hàng.");

            var cartItemsDto = cartItems.Select(CartItemToDto).ToList();
            return Ok(cartItemsDto);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { message = "Có lỗi xảy ra: " + ex.Message });
        }
    }

    [HttpGet("{cartItemId}")]
    public async Task<IActionResult> GetCartItem(int cartItemId)
    {
        if (cartItemId <= 0) return BadRequest("Lỗi ID sản phẩm");

        try
        {
            var cartItem = await _context.CartItems
                .Include(ci => ci.Product)
                .ThenInclude(p => p.ProductImages)
                .Include(ci => ci.Cart)
                .FirstOrDefaultAsync(ci => ci.CartItemId == cartItemId);

            if (cartItem == null) return NotFound("Sản phẩm không tồn tại trong giỏ hàng");

            var cartItemDto = CartItemToDto(cartItem);
            return Ok(cartItemDto);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
        }
    }

    [HttpPost]
    public async Task<IActionResult> CreateCartItem([FromBody] CreateCartItemRequest request)
    {
        if (request == null || request.CartId <= 0 || request.ProductId <= 0 || request.Quantity <= 0)
            return BadRequest("Yêu cầu không hợp lệ");

        try
        {
            var cart = await _context.Carts.FindAsync(request.CartId);
            if (cart == null) return NotFound("Giỏ hàng không tồn tại");

            var product = await _context.Products
                .Include(p => p.ProductSizes)
                .FirstOrDefaultAsync(p => p.ProductId == request.ProductId);
            if (product == null) return NotFound("Sản phẩm không tồn tại");

            var shoeSize = product.ProductSizes.FirstOrDefault(ps => ps.Size == request.Size);
            if (shoeSize == null || shoeSize.StockQuantity < request.Quantity)
                return BadRequest("Kích thước không hợp lệ hoặc số lượng không đủ");

            var existingCartItem = await _context.CartItems
                .FirstOrDefaultAsync(ci => ci.CartId == request.CartId &&
                                           ci.ProductId == request.ProductId &&
                                           ci.Size == request.Size);

            if (existingCartItem != null)
            {
                existingCartItem.Quantity += request.Quantity;
                existingCartItem.PurchaseDate = request.PurchaseDate;
                _context.Entry(existingCartItem).State = EntityState.Modified;
            }
            else
            {
                var cartItem = new CartItem
                {
                    CartId = request.CartId,
                    ProductId = request.ProductId,
                    Size = request.Size,
                    Quantity = request.Quantity,
                    PurchaseDate = request.PurchaseDate
                };
                _context.CartItems.Add(cartItem);
            }

            await _context.SaveChangesAsync();
            var cartItemDto = await GetCartItemDtoAsync(request.CartId, request.ProductId, request.Size, request.Quantity, request.PurchaseDate);
            return CreatedAtAction(nameof(GetCartItem), new { cartItemId = cartItemDto.CartItemId }, cartItemDto);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
        }
    }

    [HttpPut("{cartItemId}")]
    public async Task<IActionResult> UpdateCartItem(int cartItemId, [FromBody] UpdateCartItemRequest request)
    {
        if (cartItemId <= 0 || request == null || request.CartItemId != cartItemId)
            return BadRequest("Yêu cầu không hợp lệ");

        try
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem == null) return NotFound("Sản phẩm không tồn tại trong giỏ hàng");

            cartItem.Quantity = request.Quantity;

            _context.Entry(cartItem).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            var cartItemDto = CartItemToDto(cartItem);
            return Ok(cartItemDto);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
        }
    }

    [HttpDelete("{cartItemId}")]
    public async Task<IActionResult> DeleteCartItem(int cartItemId)
    {
        if (cartItemId <= 0) return BadRequest("Lỗi ID sản phẩm");

        try
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem == null) return NotFound("Sản phẩm không tồn tại trong giỏ hàng");

            _context.CartItems.Remove(cartItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
        }
    }

    private CartItemDto CartItemToDto(CartItem cartItem)
    {
        return new CartItemDto
        {
            CartItemId = cartItem.CartItemId,
            ProductId = cartItem.ProductId,
            CartId = cartItem.CartId,
            Quantity = cartItem.Quantity,
            Price = cartItem.Price,
            Size = cartItem.Size,
            PurchaseDate = cartItem.PurchaseDate,
            Product = cartItem.Product != null ? new ProductDto
            {
                ProductId = cartItem.Product.ProductId,
                Name = cartItem.Product.Name,
                Price = cartItem.Product.Price,
                Brand = cartItem.Product.Brand,
                ProductImgUrl = cartItem.Product.ProductImages.FirstOrDefault()?.ImageUrl,
                Category = cartItem.Product.Category != null ? new CategoryDto
                {
                    CategoryId = cartItem.Product.Category.CategoryId,
                    Name = cartItem.Product.Category.Name
                } : null
            } : null,
            Cart = cartItem.Cart != null ? new CartDto
            {
                CartId = cartItem.Cart.CartId,
                UserId = cartItem.Cart.UserId,
                Status = cartItem.Cart.Status,
                CreatedAt = cartItem.Cart.CreatedAt,
                UpdatedAt = cartItem.Cart.UpdatedAt
            } : null
        };
    }

    private async Task<CartItemDto> GetCartItemDtoAsync(int cartId, int productId, int size, int quantity, DateTime? purchaseDate)
    {
        var cartItem = await _context.CartItems
            .Where(ci => ci.CartId == cartId && ci.ProductId == productId && ci.Size == size)
            .FirstOrDefaultAsync();

        var product = await _context.Products
            .Include(p => p.ProductImages)
            .Include(p => p.Category)
            .FirstOrDefaultAsync(p => p.ProductId == productId);

        return new CartItemDto
        {
            CartItemId = cartItem?.CartItemId ?? 0,
            ProductId = product?.ProductId ?? 0,
            CartId = cartId,
            Quantity = quantity,
            PurchaseDate = purchaseDate,
            Product = product != null ? new ProductDto
            {
                ProductId = product.ProductId,
                Name = product.Name,
                Price = product.Price,
                Brand = product.Brand,
                ProductImgUrl = product.ProductImages.FirstOrDefault()?.ImageUrl,
                Category = product.Category != null ? new CategoryDto
                {
                    CategoryId = product.Category.CategoryId,
                    Name = product.Category.Name
                } : null
            } : null
        };
    }
}
