﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebGiayAPI.DTOs;
using WebGiayAPI.Requests;
using WebGiayAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace WebGiayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly WebGiayAPIContext _context;

        public ProductsController(WebGiayAPIContext context)
        {
            _context = context;
        }

        // GET: api/products/all
        [HttpGet("all")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetAllProducts()
        {
            var products = await _context.Products
                .Include(p => p.ProductSizes)
                .Include(p => p.ProductImages)
                .Select(p => new ProductDto
                {
                    ProductId = p.ProductId,
                    Name = p.Name,
                    Price = p.Price,
                    Description = p.Description,
                    CategoryId = p.CategoryId,
                    Brand = p.Brand,
                    CreatedAt = p.CreatedAt,
                    UpdatedAt = p.UpdatedAt,
                    IsFeatured = p.IsFeatured,
                    Discount = p.Discount,
                    ProductImgUrl = p.ProductImages.FirstOrDefault().ImageUrl, // Lấy URL của ảnh đầu tiên
                    StockQuantity = p.StockQuantity,
                    ProductSizes = p.ProductSizes.Select(ps => new ProductSizeDto
                    {
                        ProductSizeId = ps.ProductSizeId,
                        Size = ps.Size,
                        StockQuantity = ps.StockQuantity
                    }).ToList(),
                    ProductImages = p.ProductImages.Select(pi => new ProductImageDto
                    {
                        ImageId = pi.ImageId,
                        ImageUrl = pi.ImageUrl,
                        CreatedAt = pi.CreatedAt
                    }).ToList()
                })
                .ToListAsync();

            return Ok(products);
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetProducts(
    [FromQuery] string size = "all",
    [FromQuery] string priceRange = "all",
    [FromQuery] string sort = "price-asc",
    [FromQuery] string name = "")
        {
            var query = _context.Products
                .Include(p => p.ProductSizes)
                .Include(p => p.ProductImages)
                .AsQueryable();

            // Lọc theo tên
            if (!string.IsNullOrWhiteSpace(name))
            {
                var lowerName = name.ToLower();
                query = query.Where(p => EF.Functions.Like(p.Name.ToLower(), $"%{lowerName}%"));
            }

            // Lọc theo kích thước
            if (size != "all" && int.TryParse(size, out var sizeInt))
            {
                query = query.Where(p => p.ProductSizes.Any(ps => ps.Size == sizeInt));
            }

            // Lọc theo khoảng giá
            if (priceRange != "all")
            {
                var priceRangeParts = priceRange.Split('-');
                if (priceRangeParts.Length == 2 &&
                    decimal.TryParse(priceRangeParts[0], out var minPrice) &&
                    decimal.TryParse(priceRangeParts[1], out var maxPrice))
                {
                    query = query.Where(p => p.Price >= minPrice && p.Price <= maxPrice);
                }
            }

            // Sắp xếp
            query = sort switch
            {
                "price-desc" => query.OrderByDescending(p => p.Price),
                "name-asc" => query.OrderBy(p => p.Name),
                "name-desc" => query.OrderByDescending(p => p.Name),
                _ => query.OrderBy(p => p.Price)
            };

            var products = await query
                .Select(p => new ProductDto
                {
                    ProductId = p.ProductId,
                    Name = p.Name,
                    Price = p.Price,
                    Description = p.Description,
                    CategoryId = p.CategoryId,
                    Brand = p.Brand,
                    CreatedAt = p.CreatedAt,
                    UpdatedAt = p.UpdatedAt,
                    IsFeatured = p.IsFeatured,
                    Discount = p.Discount,
                    ProductImgUrl = p.ProductImages.FirstOrDefault().ImageUrl,
                    StockQuantity = p.StockQuantity,
                    ProductSizes = p.ProductSizes.Select(ps => new ProductSizeDto
                    {
                        ProductSizeId = ps.ProductSizeId,
                        Size = ps.Size,
                        StockQuantity = ps.StockQuantity
                    }).ToList(),
                    ProductImages = p.ProductImages.Select(pi => new ProductImageDto
                    {
                        ImageId = pi.ImageId,
                        ImageUrl = pi.ImageUrl,
                        CreatedAt = pi.CreatedAt
                    }).ToList()
                })
                .ToListAsync();

            return Ok(products);
        }


        // GET: api/products/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductDto>> GetProduct(int id)
        {
            var product = await _context.Products
                .Include(p => p.ProductSizes)
                .Include(p => p.ProductImages)
                .Where(p => p.ProductId == id)
                .Select(p => new ProductDto
                {
                    ProductId = p.ProductId,
                    Name = p.Name,
                    Price = p.Price,
                    Description = p.Description,
                    CategoryId = p.CategoryId,
                    Brand = p.Brand,
                    CreatedAt = p.CreatedAt,
                    UpdatedAt = p.UpdatedAt,
                    IsFeatured = p.IsFeatured,
                    Discount = p.Discount,
                    ProductImgUrl = p.ProductImages.FirstOrDefault().ImageUrl, // Lấy URL của ảnh đầu tiên
                    StockQuantity = p.StockQuantity,
                    ProductSizes = p.ProductSizes.Select(ps => new ProductSizeDto
                    {
                        ProductSizeId = ps.ProductSizeId,
                        Size = ps.Size,
                        StockQuantity = ps.StockQuantity
                    }).ToList(),
                    ProductImages = p.ProductImages.Select(pi => new ProductImageDto
                    {
                        ImageId = pi.ImageId,
                        ImageUrl = pi.ImageUrl,
                        CreatedAt = pi.CreatedAt
                    }).ToList()
                })
                .FirstOrDefaultAsync();

            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // POST: api/products
        [HttpPost]
        public async Task<ActionResult<ProductDto>> CreateProduct(CreateProductRequest request)
        {
            var product = new Product
            {
                Name = request.Name,
                Price = request.Price,
                Description = request.Description,
                CategoryId = request.CategoryId,
                Brand = request.Brand,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                IsFeatured = request.IsFeatured,
                Discount = request.Discount,
                ProductImgUrl = request.ProductImgUrl,
                StockQuantity = request.StockQuantity
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProduct), new { id = product.ProductId }, product);
        }

        // PUT: api/products/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, UpdateProductRequest request)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            product.Name = request.Name;
            product.Price = request.Price;
            product.Description = request.Description;
            product.CategoryId = request.CategoryId;
            product.Brand = request.Brand;
            product.UpdatedAt = DateTime.UtcNow;
            product.IsFeatured = request.IsFeatured;
            product.Discount = request.Discount;
            product.ProductImgUrl = request.ProductImgUrl;
            product.StockQuantity = request.StockQuantity;

            _context.Entry(product).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/products/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: api/products/{id}/images
        [HttpPost("{id}/images")]
        public async Task<ActionResult<ProductImageDto>> AddProductImage(int id, CreateProductImageRequest request)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var productImage = new ProductImage
            {
                ProductId = id,
                ImageUrl = request.ImageUrl,
                CreatedAt = DateTime.UtcNow
            };

            _context.ProductImages.Add(productImage);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProductImages), new { productId = id }, new ProductImageDto
            {
                ImageId = productImage.ImageId,
                ProductId = productImage.ProductId,
                ImageUrl = productImage.ImageUrl,
                CreatedAt = productImage.CreatedAt
            });
        }

        // DELETE: api/products/{id}/images/{imageId}
        [HttpDelete("{id}/images/{imageId}")]
        public async Task<IActionResult> DeleteProductImage(int id, int imageId)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var image = await _context.ProductImages.FindAsync(imageId);
            if (image == null || image.ProductId != id)
            {
                return NotFound();
            }

            _context.ProductImages.Remove(image);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // GET: api/products/{id}/images
        [HttpGet("{id}/images")]
        public async Task<ActionResult<IEnumerable<ProductImageDto>>> GetProductImages(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var images = await _context.ProductImages
                .Where(pi => pi.ProductId == id)
                .Select(pi => new ProductImageDto
                {
                    ImageId = pi.ImageId,
                    ProductId = pi.ProductId,
                    ImageUrl = pi.ImageUrl,
                    CreatedAt = pi.CreatedAt
                })
                .ToListAsync();

            return Ok(images);
        }
    }
}
