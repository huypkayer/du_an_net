﻿using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebGiayAPI.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // Giữ nguyên tên thuộc tính trong JSON và xử lý vòng lặp tham chiếu
        options.JsonSerializerOptions.PropertyNamingPolicy = null; // Giữ nguyên tên thuộc tính
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles; // Xử lý vòng lặp tham chiếu nếu cần
        //options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase; // Sử dụng camelCase nếu cần
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Đăng ký WebGiayAPIContext với Dependency Injection container
builder.Services.AddDbContext<WebGiayAPIContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Thêm dịch vụ CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy",
        builder => builder
            .WithOrigins("http://localhost:3000")  // Thay thế bằng URL của ứng dụng frontend
            .AllowAnyMethod()
            .AllowAnyHeader());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();

// Sử dụng middleware CORS với chính sách đã cấu hình
app.UseCors("CorsPolicy");

// Cần thêm middleware để sử dụng authorization nếu cần
app.UseAuthorization();

// Map các controller
app.MapControllers();

app.Run();
