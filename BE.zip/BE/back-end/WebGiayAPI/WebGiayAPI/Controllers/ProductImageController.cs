﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebGiayAPI.DTOs;
using WebGiayAPI.Requests;
using WebGiayAPI.Models; // Đảm bảo rằng bạn đã thêm các mô hình của bạn ở đây
using Microsoft.EntityFrameworkCore;

namespace WebGiayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductImagesController : ControllerBase
    {
        private readonly WebGiayAPIContext _context;

        public ProductImagesController(WebGiayAPIContext context)
        {
            _context = context;
        }

        // GET: api/productimages
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductImageDto>>> GetProductImages()
        {
            var productImages = await _context.ProductImages
                .Select(pi => new ProductImageDto
                {
                    ImageId = pi.ImageId,
                    ProductId = pi.ProductId,
                    ImageUrl = pi.ImageUrl,
                    CreatedAt = pi.CreatedAt
                })
                .ToListAsync();

            return Ok(productImages);
        }

        // GET: api/productimages/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductImageDto>> GetProductImage(int id)
        {
            var productImage = await _context.ProductImages
                .Where(pi => pi.ImageId == id)
                .Select(pi => new ProductImageDto
                {
                    ImageId = pi.ImageId,
                    ProductId = pi.ProductId,
                    ImageUrl = pi.ImageUrl,
                    CreatedAt = pi.CreatedAt
                })
                .FirstOrDefaultAsync();

            if (productImage == null)
            {
                return NotFound();
            }

            return Ok(productImage);
        }

        // GET: api/products/{productId}/images
        [HttpGet("products/{productId}/images")]
        public async Task<ActionResult<IEnumerable<ProductImageDto>>> GetProductImagesByProduct(int productId)
        {
            var productImages = await _context.ProductImages
                .Where(pi => pi.ProductId == productId)
                .Select(pi => new ProductImageDto
                {
                    ImageId = pi.ImageId,
                    ProductId = pi.ProductId,
                    ImageUrl = pi.ImageUrl,
                    CreatedAt = pi.CreatedAt
                })
                .ToListAsync();

            if (!productImages.Any())
            {
                return NotFound();
            }

            return Ok(productImages);
        }

        // POST: api/productimages
        [HttpPost]
        public async Task<ActionResult<ProductImageDto>> CreateProductImage(CreateProductImageRequest request)
        {
            var productImage = new ProductImage
            {
                ProductId = request.ProductId,
                ImageUrl = request.ImageUrl,
                CreatedAt = DateTime.UtcNow
            };

            _context.ProductImages.Add(productImage);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProductImage), new { id = productImage.ImageId }, new ProductImageDto
            {
                ImageId = productImage.ImageId,
                ProductId = productImage.ProductId,
                ImageUrl = productImage.ImageUrl,
                CreatedAt = productImage.CreatedAt
            });
        }

        // PUT: api/productimages/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProductImage(int id, UpdateProductImageRequest request)
        {
            var productImage = await _context.ProductImages.FindAsync(id);

            if (productImage == null)
            {
                return NotFound();
            }

            productImage.ProductId = request.ProductId;
            productImage.ImageUrl = request.ImageUrl;
            productImage.CreatedAt = DateTime.UtcNow;

            _context.Entry(productImage).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/productimages/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductImage(int id)
        {
            var productImage = await _context.ProductImages.FindAsync(id);

            if (productImage == null)
            {
                return NotFound();
            }

            _context.ProductImages.Remove(productImage);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
