﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebGiayAPI.DTOs;
using WebGiayAPI.Models;
using WebGiayAPI.Requests;

namespace WebGiayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly WebGiayAPIContext _context;

        public CartController(WebGiayAPIContext context)
        {
            _context = context;
        }

        // GET: api/Cart/{userId}
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetCart(int userId)
        {
            if (userId <= 0)
            {
                return BadRequest("Lỗi ID người dùng");
            }

            try
            {
                var cart = await _context.Carts
                    .Include(c => c.CartItems)
                    .ThenInclude(ci => ci.Product)
                    .ThenInclude(p => p.ProductImages)
                    .FirstOrDefaultAsync(c => c.UserId == userId && !c.Status);

                if (cart == null)
                {
                    return NotFound("Giỏ hàng trống");
                }

                var cartDto = new CartDto
                {
                    CartId = cart.CartId,
                    UserId = cart.UserId,
                    Status = cart.Status,
                    CreatedAt = cart.CreatedAt,
                    UpdatedAt = cart.UpdatedAt,
                    CartItems = cart.CartItems.Select(ci => new CartItemDto
                    {
                        CartItemId = ci.CartItemId,
                        ProductId = ci.ProductId,
                        Size = ci.Size,
                        Product = new ProductDto
                        {
                            ProductId = ci.Product.ProductId,
                            Name = ci.Product.Name,
                            Price = ci.Product.Price,
                            Category = ci.Product.Category != null ? new CategoryDto
                            {
                                CategoryId = ci.Product.Category.CategoryId,
                                Name = ci.Product.Category.Name
                            } : null,
                            Brand = ci.Product.Brand,
                            ProductSizes = ci.Product.ProductSizes.Select(pss => new ProductSizeDto
                            {
                                ProductSizeId = pss.ProductSizeId,
                                StockQuantity = pss.StockQuantity,
                                Size = pss.Size
                            }).ToList(),
                            ProductImgUrl = ci.Product.ProductImages.FirstOrDefault()?.ImageUrl
                        },
                        Quantity = ci.Quantity,
                        Price = ci.Price
                    }).ToList()
                };

                return Ok(cartDto);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
            }
        }

        // GET: api/Cart/history/{userId}
        [HttpGet("history/{userId}")]
        public async Task<IActionResult> GetHistoryOrder(int userId)
        {
            if (userId <= 0)
            {
                return BadRequest("Lỗi ID người dùng");
            }

            try
            {
                var carts = await _context.Carts
                    .Include(c => c.CartItems)
                    .ThenInclude(ci => ci.Product)
                    .ThenInclude(p => p.ProductImages)
                    .Where(c => c.UserId == userId && c.Status)
                    .ToListAsync();

                if (carts == null || !carts.Any())
                {
                    return NotFound("Không có lịch sử mua hàng");
                }

                var cartDtos = carts.Select(cart => new CartDto
                {
                    CartId = cart.CartId,
                    UserId = cart.UserId,
                    Status = cart.Status,
                    CreatedAt = cart.CreatedAt,
                    UpdatedAt = cart.UpdatedAt,
                    CartItems = cart.CartItems.Select(ci => new CartItemDto
                    {
                        CartItemId = ci.CartItemId,
                        ProductId = ci.ProductId,
                        Size = ci.Size,
                        Product = new ProductDto
                        {
                            ProductId = ci.Product.ProductId,
                            Name = ci.Product.Name,
                            Price = ci.Product.Price,
                            Category = ci.Product.Category != null ? new CategoryDto
                            {
                                CategoryId = ci.Product.Category.CategoryId,
                                Name = ci.Product.Category.Name
                            } : null,
                            Brand = ci.Product.Brand,
                            ProductSizes = ci.Product.ProductSizes.Select(pss => new ProductSizeDto
                            {
                                ProductSizeId = pss.ProductSizeId,
                                StockQuantity = pss.StockQuantity,
                                Size = pss.Size
                            }).ToList(),
                            ProductImgUrl = ci.Product.ProductImages.FirstOrDefault()?.ImageUrl
                        },
                        Quantity = ci.Quantity,
                        Price = ci.Price,
                        PurchaseDate = ci.PurchaseDate ?? DateTime.MinValue
                    }).ToList()
                }).ToList();

                return Ok(cartDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
            }
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> AddToCart([FromBody] AddToCartRequest request)
        {
            if (request == null || request.UserId <= 0 || request.ProductId <= 0 || request.Size <= 0 || request.Quantity <= 0)
            {
                return BadRequest("Thông tin không hợp lệ.");
            }

            try
            {
                var cart = await GetOrCreateCartAsync(request.UserId);
                var updatedCart = await AddProductToCartAsync(cart, request);

                if (updatedCart != null)
                {
                    return Ok(new { cartId = updatedCart.CartId, message = "Sản phẩm đã được thêm vào giỏ hàng." });
                }
                else
                {
                    return BadRequest("Lỗi khi thêm sản phẩm vào giỏ hàng.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
            }
        }

        [HttpPost("completeCheckout")]
        public async Task<IActionResult> CompleteCheckout([FromBody] CheckoutRequest request)
        {
            if (request == null || request.UserId <= 0)
            {
                return BadRequest("Lỗi thông tin.");
            }

            try
            {
                var cart = await CompleteCheckoutProcess(request);
                return Ok("Hoàn thành thanh toán thành công!");
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        // PUT: api/Cart/updateQuantity
        [HttpPut("updateQuantity")]
        public async Task<IActionResult> UpdateCartItemQuantity([FromBody] UpdateCartItemRequest request)
        {
            if (request == null || request.CartItemId <= 0 || request.Quantity <= 0)
            {
                return BadRequest("Thông tin không hợp lệ.");
            }

            try
            {
                var cartItem = await _context.CartItems
                    .Include(ci => ci.Cart)
                    .FirstOrDefaultAsync(ci => ci.CartItemId == request.CartItemId && ci.Cart.Status == false);

                if (cartItem == null)
                {
                    return NotFound("Mục giỏ hàng không tồn tại hoặc giỏ hàng đã được hoàn tất.");
                }

                cartItem.Quantity = request.Quantity;
                cartItem.Cart.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                return Ok(new { message = "Số lượng sản phẩm đã được cập nhật." });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
            }
        }


        // DELETE: api/Cart/removeItem/{cartItemId}
        [HttpDelete("removeItem/{cartItemId}")]
        public async Task<IActionResult> RemoveItem(int cartItemId)
        {
            if (cartItemId <= 0)
            {
                return BadRequest("Lỗi ID sản phẩm");
            }

            try
            {
                await DeleteCartItemAsync(cartItemId);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = ex.Message });
            }
        }

        private async Task<Cart> GetOrCreateCartAsync(int userId)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == userId && !c.Status);

            if (cart == null)
            {
                cart = new Cart
                {
                    UserId = userId,
                    Status = false,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync();
            }

            return cart;
        }

        private async Task<CartDto> GetOrCreateCartDtoAsync(int userId)
        {
            var cart = await GetOrCreateCartAsync(userId);

            return new CartDto
            {
                CartId = cart.CartId,
                UserId = cart.UserId,
                Status = cart.Status,
                CreatedAt = cart.CreatedAt,
                UpdatedAt = cart.UpdatedAt,
                CartItems = cart.CartItems?.Select(ci => new CartItemDto
                {
                    CartItemId = ci.CartItemId,
                    ProductId = ci.ProductId,
                    Product = ci.Product != null ? new ProductDto
                    {
                        ProductId = ci.Product.ProductId,
                        Name = ci.Product.Name,
                        Brand = ci.Product.Brand,
                        Price = ci.Product.Price,
                        ProductSizes = ci.Product.ProductSizes?.Select(pss => new ProductSizeDto
                        {
                            ProductSizeId = pss.ProductSizeId,
                            StockQuantity = pss.StockQuantity,
                            Size = pss.Size
                        }).ToList(),
                        ProductImgUrl = ci.Product.ProductImages?.FirstOrDefault()?.ImageUrl,
                        Category = ci.Product.Category != null ? new CategoryDto
                        {
                            CategoryId = ci.Product.Category.CategoryId,
                            Name = ci.Product.Category.Name
                        } : null
                    } : null,
                    Quantity = ci.Quantity,
                    Price = ci.Price,
                    PurchaseDate = ci.PurchaseDate ?? DateTime.MinValue
                }).ToList()
            };
        }

        private async Task<Cart> AddProductToCartAsync(Cart cart, AddToCartRequest request)
        {
            var cartItem = cart.CartItems.FirstOrDefault(ci => ci.ProductId == request.ProductId && ci.Size == request.Size);
            var product = await _context.Products.FindAsync(request.ProductId);

            if (product == null)
            {
                return null;
            }

            if (cartItem != null)
            {
                cartItem.Quantity += request.Quantity;
            }
            else
            {
                cartItem = new CartItem
                {
                    CartId = cart.CartId,
                    ProductId = request.ProductId,
                    Quantity = request.Quantity,
                    Price = product.Price,
                    Size = request.Size
                };
                cart.CartItems.Add(cartItem);
            }

            cart.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return cart;
        }

        private async Task<Cart> CompleteCheckoutProcess(CheckoutRequest request)
        {
            // Truy vấn giỏ hàng của người dùng chưa thanh toán và bao gồm thông tin người dùng
            var cart = await _context.Carts.Include(c => c.CartItems)
                                            .ThenInclude(ci => ci.Product)
                                            .ThenInclude(p => p.ProductSizes) // Bao gồm ProductSizes trong truy vấn
                                            .Include(c => c.User) // Bao gồm thông tin người dùng trong truy vấn
                                            .FirstOrDefaultAsync(c => c.UserId == request.UserId && c.Status == false);

            if (cart == null)
            {
                throw new Exception("Không tìm thấy giỏ hàng của người dùng");
            }

            // Cập nhật số lượng tồn kho cho từng sản phẩm trong giỏ hàng
            foreach (var cartItem in cart.CartItems)
            {
                var product = cartItem.Product;

                // Giả sử bạn có thuộc tính Size trong cartItem để chỉ định kích thước sản phẩm
                var productSize = product.ProductSizes.FirstOrDefault(ps => ps.Size == cartItem.Size);

                if (productSize == null)
                {
                    throw new Exception($"Kích thước {cartItem.Size} cho sản phẩm {product.Name} không tồn tại");
                }

                // Kiểm tra số lượng tồn kho cho kích thước cụ thể
                if (productSize.StockQuantity < cartItem.Quantity)
                {
                    throw new Exception($"Không đủ số lượng cho sản phẩm {product.Name} kích thước {cartItem.Size}");
                }

                // Trừ số lượng tồn kho cho kích thước cụ thể
                productSize.StockQuantity -= cartItem.Quantity;
            }
            
            // Cập nhật thông tin thanh toán và trạng thái giỏ hàng
            // Cập nhật thông tin người dùng từ thông tin người dùng đã bao gồm trong giỏ hàng
            cart.CreatedAt = DateTime.UtcNow;
            cart.Status = true;

            // Nếu bạn muốn cập nhật địa chỉ người dùng, bạn có thể lấy từ thuộc tính User của giỏ hàng
            // cart.Address = cart.User.Address; // Giả sử bạn có thuộc tính Address trong Cart

            // Lưu thay đổi vào cơ sở dữ liệu
            await _context.SaveChangesAsync();
            return cart;
        }



        private async Task DeleteCartItemAsync(int cartItemId)
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem != null)
            {
                _context.CartItems.Remove(cartItem);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Mục giỏ hàng không tồn tại.");
            }
        }
    }
}
