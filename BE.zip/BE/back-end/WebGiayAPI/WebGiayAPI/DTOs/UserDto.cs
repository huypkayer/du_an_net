﻿namespace WebGiayAPI.DTOs
{
    public class UserDto
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Role { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string Address { get; set; }
        public decimal? Salary { get; set; }
        public bool IsActive { get; set; }
        public string AvatarUrl { get; set; }
        public DateTime? LastLogin { get; set; }
        public string Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }

        // Các thuộc tính điều hướng
        public List<CartDto> Carts { get; set; } = new List<CartDto>();
    }
}
