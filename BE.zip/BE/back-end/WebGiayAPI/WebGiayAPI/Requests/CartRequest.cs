﻿namespace WebGiayAPI.Requests
{
    public class AddToCartRequest
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int Size { get; set; }
        public int Quantity { get; set; }

    }

    public class DoneCartRequest
    {
        public int UserId { get; set; }
        public string UserName {  get; set; }
        public int NumberPhone { get; set; }
        public string Addresss { get; set; }
    }

    public class CreateCartRequest
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public int Size { get; set; }
    }
    public class UpdateCartRequest
    {
        public int UserId { get; set; }
        public int CartId { get; set; }

        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public int Size { get; set; }
        public bool Status { get; set; }
    }

}
